<?php
		$Validation=new CBSValidation();
?>
			<tr>
				<td<?php echo $this->data['format']['header']; ?>><?php esc_html_e('Booking details',PLUGIN_CBS_DOMAIN); ?></td>
			</tr>
			<tr><td<?php echo $this->data['format']['separator'][3]; ?>><td></tr>
			<tr>
				<td>
					<table cellspacing="0" cellpadding="0">
						<tr>
							<td<?php echo $this->data['format']['cell'][1]; ?>><?php esc_html_e('Booking',PLUGIN_CBS_DOMAIN); ?></td>
							<td<?php echo $this->data['format']['cell'][2]; ?>><?php echo esc_html($this->data['booking']['post']->post_title); ?></td>
						</tr>
						<tr>
							<td<?php echo $this->data['format']['cell'][1]; ?>><?php esc_html_e('Status',PLUGIN_CBS_DOMAIN); ?></td>
							<td<?php echo $this->data['format']['cell'][2]; ?>><?php echo esc_html($this->data['other']['bookingStatus']); ?></td>
						</tr>
						<tr>
							<td<?php echo $this->data['format']['cell'][1]; ?>><?php esc_html_e('Duration',PLUGIN_CBS_DOMAIN); ?></td>
							<td<?php echo $this->data['format']['cell'][2]; ?>><?php echo esc_html($this->data['other']['bookingDuration']); ?></td>
						</tr>
						<tr>
							<td<?php echo $this->data['format']['cell'][1]; ?>><?php esc_html_e('Price',PLUGIN_CBS_DOMAIN); ?></td>
							<td<?php echo $this->data['format']['cell'][2]; ?>><?php echo esc_html($this->data['other']['bookingPrice']); ?></td>
						</tr>
						<tr>
							<td<?php echo $this->data['format']['cell'][1]; ?>><?php esc_html_e('Selected vehicle',PLUGIN_CBS_DOMAIN); ?></td>
							<td<?php echo $this->data['format']['cell'][2]; ?>><?php echo esc_html($this->data['booking']['meta']['vehicle_name']); ?></td>
						</tr>
<?php
		if($this->data['booking']['meta']['package_id']!=0)
		{
?>
						<tr>
							<td<?php echo $this->data['format']['cell'][1]; ?>><?php esc_html_e('Selected package',PLUGIN_CBS_DOMAIN); ?></td>
							<td<?php echo $this->data['format']['cell'][2]; ?>><?php echo esc_html($this->data['booking']['meta']['package_name']); ?></td>
						</tr>
<?php
		}
?>
					</table>
				</td>
			</tr>