
		<div class="to">
			
			<div class="to-tab">
				
				<ul>
					<li><a href="#cbs-payment-paypal"><?php esc_html_e('Paypal',PLUGIN_CBS_DOMAIN); ?></a></li>
				</ul>
					
				<div id="cbs-payment-paypal">
					
					<ul class="to-form-field-list">
						<li>
							<h5><?php esc_html_e('Enable PayPal',PLUGIN_CBS_DOMAIN); ?></h5>
							<span class="to-legend">
								<?php esc_html_e('Enable PayPal.',PLUGIN_CBS_DOMAIN); ?>
							</span>
							<div class="to-radio-button">
								<input type="radio" value="1" id="<?php CBSHelper::getFormName('payment_paypal_enable_1'); ?>" name="<?php CBSHelper::getFormName('payment_paypal_enable'); ?>" <?php CBSHelper::checkedIf($this->data['meta']['payment_paypal_enable'],1); ?>/>
								<label for="<?php CBSHelper::getFormName('payment_paypal_enable_1'); ?>"><?php esc_html_e('Enable',PLUGIN_CBS_DOMAIN); ?></label>							
								<input type="radio" value="0" id="<?php CBSHelper::getFormName('payment_paypal_enable_0'); ?>" name="<?php CBSHelper::getFormName('payment_paypal_enable'); ?>" <?php CBSHelper::checkedIf($this->data['meta']['payment_paypal_enable'],0); ?>/>
								<label for="<?php CBSHelper::getFormName('payment_paypal_enable_0'); ?>"><?php esc_html_e('Disable',PLUGIN_CBS_DOMAIN); ?></label>							
							</div>
						</li>
						<li>
							<h5><?php esc_html_e('E-mail address',PLUGIN_CBS_DOMAIN); ?></h5>
							<span class="to-legend"><?php esc_html_e('Business e-mail address.',PLUGIN_CBS_DOMAIN); ?></span>
							<div>
								<input type="text" name="<?php CBSHelper::getFormName('payment_paypal_email_address'); ?>" id="<?php CBSHelper::getFormName('payment_paypal_email_address'); ?>" value="<?php echo esc_attr($this->data['meta']['payment_paypal_email_address']); ?>"/>
							</div>
						</li>
					</ul>
					
				</div>
				
			</div>
				
		</div>
