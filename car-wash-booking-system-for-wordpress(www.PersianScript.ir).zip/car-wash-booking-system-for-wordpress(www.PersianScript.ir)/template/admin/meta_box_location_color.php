		
		<div class="to">
			<ul class="to-form-field-list">
<?php
		$text=array
		(
			__('Main color scheme'),
			__('Secondary color scheme',PLUGIN_CBS_DOMAIN),
			__('Heading text',PLUGIN_CBS_DOMAIN),
			__('Body text',PLUGIN_CBS_DOMAIN),
			__('Subtle body text',PLUGIN_CBS_DOMAIN),
			__('Border',PLUGIN_CBS_DOMAIN),
			__('Inactive step background',PLUGIN_CBS_DOMAIN),
			__('Inactive step text',PLUGIN_CBS_DOMAIN),
			__('Inactive body text',PLUGIN_CBS_DOMAIN),
			__('Icon',PLUGIN_CBS_DOMAIN)
		);

		for($i=1;$i<=$this->data['colorCount'];$i++)
		{
?>
				<li>
					<h5><?php echo $text[$i-1]; ?></h5>
					<span class="to-legend">
						<?php esc_html_e('Select color in HEX format for elements in this group. Leave the field blank to use the default color.',PLUGIN_CBS_DOMAIN); ?><br/>
						<?php echo sprintf(esc_html__('More info about colors you can find %shere%s.',PLUGIN_CBS_DOMAIN),'<a href="'.PLUGIN_CBS_MEDIA_URL.'image/admin/color.png" target="_blank">','</a>'); ?>
					</span>
					<div>
						<input type="text" class="to-color-picker" name="<?php CBSHelper::getFormName('color_'.$i); ?>" id="<?php CBSHelper::getFormName('color_'.$i); ?>" value="<?php echo esc_attr($this->data['meta']['color'][$i]); ?>"/>
					</div>
				</li>
<?php
		}
?>
			</ul>

		</div>