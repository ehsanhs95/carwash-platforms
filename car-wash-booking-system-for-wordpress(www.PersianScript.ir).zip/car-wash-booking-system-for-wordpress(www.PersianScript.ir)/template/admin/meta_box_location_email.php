		
		<div class="to">
			<ul class="to-form-field-list">
				<li>
					<h5><?php esc_html_e('Sender account name',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend"><?php esc_html_e('Sender account name.',PLUGIN_CBS_DOMAIN); ?></span>
					<div>
						<input type="text" name="<?php CBSHelper::getFormName('sender_name'); ?>" id="<?php CBSHelper::getFormName('sender_name'); ?>" value="<?php echo esc_attr($this->data['meta']['sender_name']); ?>"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('Sender account e-mail address',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend"><?php esc_html_e('Sender account e-mail address.',PLUGIN_CBS_DOMAIN); ?></span>
					<div>
						<input type="text" name="<?php CBSHelper::getFormName('sender_email'); ?>" id="<?php CBSHelper::getFormName('sender_email'); ?>" value="<?php echo esc_attr($this->data['meta']['sender_email']); ?>"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('Sender account SMTP support',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend"><?php esc_html_e('Sender account SMTP support.',PLUGIN_CBS_DOMAIN); ?></span>
					<div class="to-radio-button">
						<input type="radio" value="1" id="<?php CBSHelper::getFormName('sender_smtp_enable_1'); ?>" name="<?php CBSHelper::getFormName('sender_smtp_enable'); ?>" <?php CBSHelper::checkedIf($this->data['meta']['sender_smtp_enable'],1); ?>/>
						<label for="<?php CBSHelper::getFormName('sender_smtp_enable_1'); ?>"><?php esc_html_e('Enabled',PLUGIN_CBS_DOMAIN); ?></label>
						<input type="radio" value="0" id="<?php CBSHelper::getFormName('sender_smtp_enable_0'); ?>" name="<?php CBSHelper::getFormName('sender_smtp_enable'); ?>" <?php CBSHelper::checkedIf($this->data['meta']['sender_smtp_enable'],0); ?>/>
						<label for="<?php CBSHelper::getFormName('sender_smtp_enable_0'); ?>"><?php esc_html_e('Disabled',PLUGIN_CBS_DOMAIN); ?></label>							
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('Sender account SMTP username',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend"><?php esc_html_e('Sender account SMTP username.',PLUGIN_CBS_DOMAIN); ?></span>
					<div>
						<input type="text" name="<?php CBSHelper::getFormName('sender_smtp_username'); ?>" id="<?php CBSHelper::getFormName('sender_smtp_username'); ?>" value="<?php echo esc_attr($this->data['meta']['sender_smtp_username']); ?>"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('Sender account SMTP password',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend"><?php esc_html_e('Sender account SMTP password.',PLUGIN_CBS_DOMAIN); ?></span>
					<div>
						<input type="password" name="<?php CBSHelper::getFormName('sender_smtp_password'); ?>" id="<?php CBSHelper::getFormName('sender_smtp_password'); ?>" value="<?php echo esc_attr($this->data['meta']['sender_smtp_password']); ?>"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('Sender account SMTP host',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend"><?php esc_html_e('Sender account SMTP host.',PLUGIN_CBS_DOMAIN); ?></span>
					<div>
						<input type="text" name="<?php CBSHelper::getFormName('sender_smtp_host'); ?>" id="<?php CBSHelper::getFormName('sender_smtp_host'); ?>" value="<?php echo esc_attr($this->data['meta']['sender_smtp_host']); ?>"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('Sender account SMTP port',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend"><?php esc_html_e('Sender account SMTP port.',PLUGIN_CBS_DOMAIN); ?></span>
					<div>
						<input type="text" name="<?php CBSHelper::getFormName('sender_smtp_port'); ?>" id="<?php CBSHelper::getFormName('sender_smtp_port'); ?>" value="<?php echo esc_attr($this->data['meta']['sender_smtp_port']); ?>"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('Sender account SMTP connection type',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend"><?php esc_html_e('Sender account SMTP connection type.',PLUGIN_CBS_DOMAIN); ?></span>
					<div class="to-radio-button">
<?php
		foreach($this->data['dictionary']['secureConnectionType'] as $secureConnectionTypeIndex=>$secureConnectionTypeData)
		{
?>
							<input type="radio" value="<?php echo esc_attr($secureConnectionTypeIndex); ?>" id="<?php CBSHelper::getFormName('sender_smtp_secure_connection_type_'.$secureConnectionTypeIndex); ?>" name="<?php CBSHelper::getFormName('sender_smtp_secure_connection_type'); ?>" <?php CBSHelper::checkedIf($this->data['meta']['sender_smtp_secure_connection_type'],$secureConnectionTypeIndex); ?>/>
							<label for="<?php CBSHelper::getFormName('sender_smtp_secure_connection_type_'.$secureConnectionTypeIndex); ?>"><?php echo esc_html($secureConnectionTypeData[0]); ?></label>							
<?php		
		}
?>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('SMTP debug',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend">
						<?php esc_html_e('Enable or disable SMTP debugging.',PLUGIN_CBS_DOMAIN); ?><br/>
						<?php esc_html_e('You can check result of debugging in Chrome/Firebug console (after submit form).',PLUGIN_CBS_DOMAIN); ?>
					</span>
					<div class="to-radio-button">
						<input type="radio" value="1" id="<?php CBSHelper::getFormName('smtp_debug_enable_1'); ?>" name="<?php CBSHelper::getFormName('smtp_debug_enable'); ?>" <?php CBSHelper::checkedIf($this->data['meta']['smtp_debug_enable'],1); ?>/>
						<label for="<?php CBSHelper::getFormName('smtp_debug_enable_1'); ?>"><?php esc_html_e('Enabled',PLUGIN_CBS_DOMAIN); ?></label>							
						<input type="radio" value="0" id="<?php CBSHelper::getFormName('smtp_debug_enable_0'); ?>" name="<?php CBSHelper::getFormName('smtp_debug_enable'); ?>" <?php CBSHelper::checkedIf($this->data['meta']['smtp_debug_enable'],0); ?>/>
						<label for="<?php CBSHelper::getFormName('smtp_debug_enable_0'); ?>"><?php esc_html_e('Disabled',PLUGIN_CBS_DOMAIN); ?></label>							
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('Recipient e-mail addresses',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend"><?php esc_html_e('Recipient e-mail addresses separated by semicolon.',PLUGIN_CBS_DOMAIN); ?></span>
					<div>
						<input type="text" name="<?php CBSHelper::getFormName('recipient_email'); ?>" id="<?php CBSHelper::getFormName('recipient_email'); ?>" value="<?php echo esc_attr($this->data['meta']['recipient_email']); ?>"/>
					</div>
				</li>
			</ul>
		</div>