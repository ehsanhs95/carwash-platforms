
		<tr>
			<td>
				<?php esc_html_e('A new booking has been received.'); ?><br/>
				<?php echo sprintf(esc_html__('To view it, simply click on this link: %s.',PLUGIN_CBS_DOMAIN),$this->data['other']['bookingUrl']); ?><br/>
			</td>
		</tr>