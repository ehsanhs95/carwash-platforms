
	<div class="cbs-main-list-item-section-content cbs-clear-fix">
		<div class="cbs-form-field cbs-form-field-first-name cbs-form-width-33">
			<label><?php esc_html_e('First name *',PLUGIN_CBS_DOMAIN); ?></label>
			<input type="text" name="client_first_name" autocomplete="off" />
		</div>
		<div class="cbs-form-field cbs-form-field-last-name cbs-form-width-33">
			<label><?php esc_html_e('Second name *',PLUGIN_CBS_DOMAIN); ?></label>
			<input type="text" name="client_second_name" autocomplete="off"  />
		</div>
		<div class="cbs-form-field cbs-form-field-model cbs-form-width-33">
			<label><?php esc_html_e('Vehicle Make and Model *',PLUGIN_CBS_DOMAIN); ?></label>
			<input type="text" name="client_vehicle" autocomplete="off" />
		</div>
		<div class="cbs-form-field cbs-form-field-email cbs-form-width-50">
			<label><?php esc_html_e('Your E-mail *',PLUGIN_CBS_DOMAIN); ?></label>
			<input type="text" name="client_email_address" autocomplete="off" />
		</div>
		<div class="cbs-form-field cbs-form-field-phone cbs-form-width-50">
			<label><?php esc_html_e('Phone Number *',PLUGIN_CBS_DOMAIN); ?></label>
			<input type="text" name="client_phone_number" autocomplete="off" />
		</div>
		<div class="cbs-form-field cbs-form-field-message cbs-form-width-100">
			<label><?php esc_html_e('Message',PLUGIN_CBS_DOMAIN); ?></label>
			<textarea rows="1" cols="1" name="client_message"></textarea>
		</div>
		<div class="cbs-form-summary cbs-clear-fix">
<?php
		$Validation=new CBSValidation();
		if($Validation->isNotEmpty($this->data['text_1']))
		{
?>
			<div class="cbs-form-info"><?php echo nl2br(esc_html($this->data['text_1'])); ?></div>
<?php
		}
?>
			<input type="submit" class="cbs-button" value="<?php esc_attr_e('Confirm Booking',PLUGIN_CBS_DOMAIN); ?>" />
		</div>
	</div>


		
