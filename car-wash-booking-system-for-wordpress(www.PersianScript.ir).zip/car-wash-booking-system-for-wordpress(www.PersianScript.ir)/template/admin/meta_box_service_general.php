<?php 
		echo $this->data['nonce']; 
?>
		<div class="to">
			<ul class="to-form-field-list">
				<li>
					<h5><?php esc_html_e('Base price',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend">
						<?php esc_html_e('Enter the base price of the service in value.',PLUGIN_CBS_DOMAIN); ?><br/>
						<?php esc_html_e('This value is used when the price for the location and vehicle type is not set.',PLUGIN_CBS_DOMAIN); ?><br/>
					</span>
					<div>
						<input type="text" value="<?php echo esc_attr(CBSPrice::formatToDisplay($this->data['meta']['base_price'])); ?>" id="<?php CBSHelper::getFormName('base_price'); ?>" name="<?php CBSHelper::getFormName('base_price'); ?>" maxlength="12"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('Base duration',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend">
						<?php esc_html_e('Enter the base duration of the service in minutes.',PLUGIN_CBS_DOMAIN); ?><br/>
						<?php esc_html_e('This value is used when the duration for the location and vehicle type is not set.',PLUGIN_CBS_DOMAIN); ?><br/>
					</span>
					<div>
						<input type="text" value="<?php echo esc_attr($this->data['meta']['base_duration']); ?>" id="<?php CBSHelper::getFormName('base_duration'); ?>" name="<?php CBSHelper::getFormName('base_duration'); ?>" maxlength="9"/>
					</div>
				</li>				
			</ul>
		</div>