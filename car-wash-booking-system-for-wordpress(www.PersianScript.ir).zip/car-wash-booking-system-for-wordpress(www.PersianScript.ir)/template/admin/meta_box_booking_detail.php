
		<div class="to">
			<ul class="to-form-field-list">
				<li>
					<h5><?php esc_html_e('List of services',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend">
						<?php esc_html_e('List of services.',PLUGIN_CBS_DOMAIN); ?><br/>
					</span>
					<div>
						<table class="to-table">
							<thead>
								<tr>
									<th style="width:40%">
										<div>
											<?php esc_html_e('Name',PLUGIN_CBS_DOMAIN); ?>
											<span class="to-legend"><?php esc_html_e('Name',PLUGIN_CBS_DOMAIN); ?></span>
										</div>
									</th>
									<th style="width:20%">
										<div>
											<?php esc_html_e('Type',PLUGIN_CBS_DOMAIN); ?>
											<span class="to-legend"><?php esc_html_e('Type.',PLUGIN_CBS_DOMAIN); ?></span>
										</div>
									</th>
									<th style="width:20%">
										<div>
											<?php esc_html_e('Price',PLUGIN_CBS_DOMAIN); ?>
											<span class="to-legend"><?php esc_html_e('Price.',PLUGIN_CBS_DOMAIN); ?></span>
										</div>
									</th>									
									<th style="width:20%">
										<div>
											<?php esc_html_e('Duration',PLUGIN_CBS_DOMAIN); ?>
											<span class="to-legend"><?php esc_html_e('Duration in minutes.',PLUGIN_CBS_DOMAIN); ?></span>
										</div>
									</th>
								</tr>
							</thead>
							<tbody>
<?php
		foreach($this->data['detail'] as $line)
		{
?>
								<tr>
									<td>
										<div><a href="<?php echo get_edit_post_link($line->{'service_id'}); ?>"><?php esc_html_e($line->{'name'}); ?></a></div>
									</td>
									<td>
										<div>
											<?php echo esc_html($line->{'service_type_name'}); ?>
										</div>
									</td>
									<td>
										<div>
											<?php echo esc_html($line->{'service_price'}); ?>
										</div>
									</td>									
									<td>
										<div><?php esc_html_e($line->{'duration'}); ?></div>
									</td>
								</tr>								
<?php
		}
?>
							<tbody>
						</table>
					</div>
				</li>
			</ul>
		</div>
			