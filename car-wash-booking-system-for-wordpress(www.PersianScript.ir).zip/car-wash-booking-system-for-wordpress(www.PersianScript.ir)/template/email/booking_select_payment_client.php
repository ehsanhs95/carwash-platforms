
		<tr>
			<td>
				<?php echo $this->data['other']['paymentForm']; ?>
			</td>
		</tr>