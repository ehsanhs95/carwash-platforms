	
		<div class="to">
			<ul class="to-form-field-list">
				<li>
					<h5><?php esc_html_e('First name',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend">
						<?php esc_html_e('First name.',PLUGIN_CBS_DOMAIN); ?><br/>
					</span>
					<div>
						<input type="text" value="<?php echo esc_attr($this->data['meta']['client_first_name']); ?>" id="<?php CBSHelper::getFormName('client_first_name'); ?>" name="<?php CBSHelper::getFormName('client_first_name'); ?>" disabled="disabled"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('Second name',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend">
						<?php esc_html_e('Second name.',PLUGIN_CBS_DOMAIN); ?><br/>
					</span>
					<div>
						<input type="text" value="<?php echo esc_attr($this->data['meta']['client_second_name']); ?>" id="<?php CBSHelper::getFormName('client_second_name'); ?>" name="<?php CBSHelper::getFormName('client_second_name'); ?>" disabled="disabled"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('Vehicle',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend">
						<?php esc_html_e('Vehicle Make and Model.',PLUGIN_CBS_DOMAIN); ?><br/>
					</span>
					<div>
						<input type="text" value="<?php echo esc_attr($this->data['meta']['client_vehicle']); ?>" id="<?php CBSHelper::getFormName('client_vehicle'); ?>" name="<?php CBSHelper::getFormName('client_vehicle'); ?>" disabled="disabled"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('E-mail address',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend">
						<?php esc_html_e('E-mail address.',PLUGIN_CBS_DOMAIN); ?><br/>
					</span>
					<div>
						<input type="text" value="<?php echo esc_attr($this->data['meta']['client_email_address']); ?>" id="<?php CBSHelper::getFormName('client_email_address'); ?>" name="<?php CBSHelper::getFormName('client_email_address'); ?>" disabled="disabled"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('Phone number',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend">
						<?php esc_html_e('Phone number.',PLUGIN_CBS_DOMAIN); ?><br/>
					</span>
					<div>
						<input type="text" value="<?php echo esc_attr($this->data['meta']['client_phone_number']); ?>" id="<?php CBSHelper::getFormName('client_phone_number'); ?>" name="<?php CBSHelper::getFormName('client_phone_number'); ?>" disabled="disabled"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('Message',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend">
						<?php esc_html_e('Message.',PLUGIN_CBS_DOMAIN); ?><br/>
					</span>
					<div>
						<textarea rows="1" cols="1" id="<?php CBSHelper::getFormName('client_message'); ?>" name="<?php CBSHelper::getFormName('client_message'); ?>" disabled="disabled"><?php echo esc_html($this->data['meta']['client_message']); ?></textarea>
					</div>
				</li>
			</ul>
		</div>