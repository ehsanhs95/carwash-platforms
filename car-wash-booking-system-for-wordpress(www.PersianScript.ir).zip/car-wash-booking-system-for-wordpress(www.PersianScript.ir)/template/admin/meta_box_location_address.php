		
		<div class="to">
			<ul class="to-form-field-list">
				<li>
					<h5><?php esc_html_e('Name',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend"><?php esc_html_e('Name.',PLUGIN_CBS_DOMAIN); ?></span>
					<div>
						<input type="text" name="<?php CBSHelper::getFormName('address_name'); ?>" id="<?php CBSHelper::getFormName('address_name'); ?>" value="<?php echo esc_attr($this->data['meta']['address_name']); ?>"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('Street',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend"><?php esc_html_e('Street.',PLUGIN_CBS_DOMAIN); ?></span>
					<div>
						<input type="text" name="<?php CBSHelper::getFormName('address_street'); ?>" id="<?php CBSHelper::getFormName('address_street'); ?>" value="<?php echo esc_attr($this->data['meta']['address_street']); ?>"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('Postcode',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend"><?php esc_html_e('Postcode.',PLUGIN_CBS_DOMAIN); ?></span>
					<div>
						<input type="text" name="<?php CBSHelper::getFormName('address_postcode'); ?>" id="<?php CBSHelper::getFormName('address_postcode'); ?>" value="<?php echo esc_attr($this->data['meta']['address_postcode']); ?>"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('City',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend"><?php esc_html_e('City.',PLUGIN_CBS_DOMAIN); ?></span>
					<div>
						<input type="text" name="<?php CBSHelper::getFormName('address_city'); ?>" id="<?php CBSHelper::getFormName('address_city'); ?>" value="<?php echo esc_attr($this->data['meta']['address_city']); ?>"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('State',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend"><?php esc_html_e('State.',PLUGIN_CBS_DOMAIN); ?></span>
					<div>
						<input type="text" name="<?php CBSHelper::getFormName('address_state'); ?>" id="<?php CBSHelper::getFormName('address_state'); ?>" value="<?php echo esc_attr($this->data['meta']['address_state']); ?>"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('Country',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend"><?php esc_html_e('Country.',PLUGIN_CBS_DOMAIN); ?></span>
					<div>
						<input type="text" name="<?php CBSHelper::getFormName('address_country'); ?>" id="<?php CBSHelper::getFormName('address_country'); ?>" value="<?php echo esc_attr($this->data['meta']['address_country']); ?>"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('Phone number',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend"><?php esc_html_e('Phone number.',PLUGIN_CBS_DOMAIN); ?></span>
					<div>
						<input type="text" name="<?php CBSHelper::getFormName('address_phone_number'); ?>" id="<?php CBSHelper::getFormName('address_phone_number'); ?>" value="<?php echo esc_attr($this->data['meta']['address_phone_number']); ?>"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('Fax number',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend"><?php esc_html_e('Fax number.',PLUGIN_CBS_DOMAIN); ?></span>
					<div>
						<input type="text" name="<?php CBSHelper::getFormName('address_fax_number'); ?>" id="<?php CBSHelper::getFormName('address_fax_number'); ?>" value="<?php echo esc_attr($this->data['meta']['address_fax_number']); ?>"/>
					</div>
				</li>
				<li>
					<h5><?php esc_html_e('E-mail address.',PLUGIN_CBS_DOMAIN); ?></h5>
					<span class="to-legend"><?php esc_html_e('E-mail address.',PLUGIN_CBS_DOMAIN); ?></span>
					<div>
						<input type="text" name="<?php CBSHelper::getFormName('address_email_address'); ?>" id="<?php CBSHelper::getFormName('address_email_address'); ?>" value="<?php echo esc_attr($this->data['meta']['address_email_address']); ?>"/>
					</div>
				</li>
			</ul>
		</div>